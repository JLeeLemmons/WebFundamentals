function changeName(){
    var button = document.querySelector("#name");
    button.innerHTML = "Doe Jane"; 
}
function removeUser(){
    var user = document.querySelector("#clear");
    user.remove(); 
}
function removeUser1(){
    var user1 = document.querySelector("#clear1"); 
    user1.remove(); 
}