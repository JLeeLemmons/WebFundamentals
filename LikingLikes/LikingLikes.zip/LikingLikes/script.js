function like1(){
    var newAmount1 = document.querySelector("#amount1");
    newAmount1.innerHTML = parseInt(newAmount1.textContent)+1+" like(s)";
}
function like2(){
    var newAmount2 = document.querySelector("#amount2");
    newAmount2.innerHTML = parseInt(newAmount2.textContent)+1+" like(s)";
}
function like3(){
    var newAmount3 = document.querySelector("#amount3");
    newAmount3.innerHTML = parseInt(newAmount3.textContent)+1+" like(s)";
        
}