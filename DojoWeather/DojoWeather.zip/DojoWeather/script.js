function alertIcon(){
    alert("Loading weather report!"); 
}
function cookieRemove(){
    var button = document.querySelector("#cookie");
    button.remove(); 
}